🛡 CyberGuardians: Gamified Human Error Training
Done by:Sree kirthana AIML-B, 24671A73C4

Project Overview

This project, CyberGuardians, was developed as part of the HACKX program, addressing a critical issue in modern data security.

Topic: Data Security

This application specifically tackles Problem Statement 4: 'Human error remains the biggest vulnerability in cybersecurity breaches.'

The goal is to provide an interactive, gamified training module to test and improve user awareness regarding common cyber threats like phishing, password misuse, and social engineering, directly mitigating the risk posed by human error.

🔑 Key Features

Gamified Learning: Users earn points and unlock special Badges (e.g., "Phish Hunter," "Key Master") for correct answers.

Module Selection: Users can choose specific focus areas (Phishing Awareness, Password Fortress, Social Sleuth).

Immediate Feedback: Provides detailed, context-specific feedback on why an answer was correct or incorrect, turning mistakes into learning opportunities.

Responsive Design: Optimized for seamless use on both mobile and desktop devices.

Single-File Architecture: The entire application is self-contained in one HTML file for maximum portability and simplicity.

🛠 Technology Stack

This application is built entirely using front-end web technologies, focusing on lightweight and dynamic rendering:

HTML5: Provides the foundational structure of the application.

JavaScript (ES6/Vanilla JS): This is the core logic engine. It handles all game state management, dynamic UI rendering, event handling, and quiz flow.

Tailwind CSS (via CDN): Used for all styling. This utility-first framework ensures a clean, modern, and fully responsive design with minimal custom CSS.

CSS3: Contains a small block of custom CSS for core variables and hover/transition effects.

🚀 How to Run

Save the cyber_guardians_js.html file to your computer.

Open the file directly in any modern web browser (Chrome, Firefox, Edge, etc.). No server or compilation steps are required.

🙏 Acknowledgments

I am incredibly grateful for the opportunity provided by the HACKX program organized by JBIET. This initiative allowed me to focus on a vital area of data security and apply modern web development skills to create a practical, engaging solution. Thank you for the platform and the challenge!
